document.addEventListener("DOMContentLoaded", () => {
    fetch("supportData.json")
        .then(response => response.json())
        .then(data => {
            populateSupportData(data);
        })
        .catch(error => console.error("Error fetching support data:", error));
});

function populateSupportData(data) {
    document.querySelector(".contact-details p:nth-of-type(1)").textContent = `Office Address: ${data.officeAddress}`;
    document.querySelector(".contact-details p:nth-of-type(2)").textContent = `Phone: ${data.phone}`;
    document.querySelector(".contact-details p:nth-of-type(3)").textContent = `Email: ${data.email}`;
    document.querySelector(".support-map img").src = data.mapImage;
}