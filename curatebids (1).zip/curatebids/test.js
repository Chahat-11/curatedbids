document.addEventListener("DOMContentLoaded", () => {
    fetch("test.json")
        .then(response => response.json())
        .then(data => {
            populateUserInfo(data.user);
            populateUserBids(data.bids);
        })
        .catch(error => console.error("Error fetching data:", error));
});

function populateUserInfo(user) {
    const userInfo = document.querySelector(".user-info");

    // Set profile picture
    const profileImg = userInfo.querySelector("img");
    profileImg.src = user.profilePicture;
    profileImg.alt = `${user.name}'s profile picture`;

    // Set user details
    userInfo.querySelector("h2").textContent = `Name: ${user.name}`;
    userInfo.querySelector("p:nth-of-type(1)").textContent = `Registration no.: ${user.registrationNo}`;
    userInfo.querySelector("p:nth-of-type(2)").textContent = `Current Bids: ${user.currentBids}`;
    userInfo.querySelector("p:nth-of-type(3)").textContent = `Your Bids: ${user.yourBids}`;
    userInfo.querySelector("p:nth-of-type(4)").textContent = `Contact no.: ${user.contactNo}`;
}

function populateUserBids(bids) {
    const bidsContainer = document.querySelector(".bids-container");
    bidsContainer.innerHTML = ""; // Clear any existing content

    bids.forEach(bid => {
        const bidItem = document.createElement("div");
        bidItem.className = "bid-item";

        const yourBid = document.createElement("p");
        yourBid.textContent = `Your Bid Price: $${bid.yourBidPrice}`;

        const currentBid = document.createElement("p");
        currentBid.textContent = `Current Bid Price: $${bid.currentBidPrice}`;

        bidItem.appendChild(yourBid);
        bidItem.appendChild(currentBid);
        bidsContainer.appendChild(bidItem);
    });
}