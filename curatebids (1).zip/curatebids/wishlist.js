document.addEventListener("DOMContentLoaded", () => {
    fetch("wishlistData.json")
        .then(response => response.json())
        .then(data => {
            displayWishlistItems(data.wishlistItems);
        })
        .catch(error => console.error("Error fetching wishlist data:", error));
});

function displayWishlistItems(items) {
    const wishlistContainer = document.querySelector(".wishlist-container");
    wishlistContainer.innerHTML = ""; // Clear existing content

    items.forEach(item => {
        const wishlistItem = document.createElement("div");
        wishlistItem.classList.add("wishlist-item");

        wishlistItem.innerHTML = `
            <div class="wishlist-photo">
                <img src="${item.imageSrc}" alt="Product Image">
            </div>
            <div class="wishlist-info">
                <p>Product Name: ${item.productName}</p>
                <p>Current Bid: ${item.currentBid}</p>
                <p>Bid Ends: ${item.bidEnds}</p>
                <button class="bid-now">Bid Now</button>
            </div>
        `;

        wishlistContainer.appendChild(wishlistItem);
    });
}