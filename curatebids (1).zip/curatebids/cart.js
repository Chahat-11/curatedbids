document.addEventListener("DOMContentLoaded", () => {
    fetch("cartData.json")
        .then(response => response.json())
        .then(data => {
            populateCartItems(data.cartItems);
            calculateTotal(data.cartItems);
        })
        .catch(error => console.error("Error fetching cart data:", error));
});

function populateCartItems(cartItems) {
    const cartContainer = document.querySelector(".cart-items");
    cartContainer.innerHTML = ""; // Clear any existing content

    cartItems.forEach(item => {
        const cartItem = document.createElement("div");
        cartItem.className = "cart-item";

        const cartPhoto = document.createElement("div");
        cartPhoto.className = "cart-photo";
        const img = document.createElement("img");
        img.src = item.image;
        img.alt = item.productName;
        cartPhoto.appendChild(img);

        const cartInfo = document.createElement("div");
        cartInfo.className = "cart-info";
        const productName = document.createElement("p");
        productName.textContent = `Product Name: ${item.productName}`;
        const price = document.createElement("p");
        price.textContent = `Price: $${item.price}`;
        const removeButton = document.createElement("button");
        removeButton.className = "remove-item";
        removeButton.textContent = "Remove";
        removeButton.addEventListener("click", () => {
            cartItem.remove();
            calculateTotal(cartItems);
        });

        cartInfo.appendChild(productName);
        cartInfo.appendChild(price);
        cartInfo.appendChild(removeButton);

        cartItem.appendChild(cartPhoto);
        cartItem.appendChild(cartInfo);
        cartContainer.appendChild(cartItem);
    });
}

function calculateTotal(cartItems) {
    const total = cartItems.reduce((sum, item) => sum + item.price, 0);
    document.querySelector(".cart-total h3").textContent = `Total: $${total}`;
}