// Import required modules
const express = require('express');
const mongoose = require('mongoose');

// Initialize the Express app
const app = express();
const PORT = 3000; // You can change the port if needed

// Middleware to parse JSON
app.use(express.json());

// MongoDB connection URL (replace with your MongoDB URI)
const DB_URI = 'mongodb+srv://noog:pushkar123@cluster0.nnd04.mongodb.net/curatebids'; // Replace 'mydatabase' with your DB name

// Connect to MongoDB using Mongoose
mongoose
    .connect(DB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('Connected to MongoDB'))
    .catch((error) => console.error('Error connecting to MongoDB:', error));

// Define a Mongoose Schema
const userSchema = new mongoose.Schema({
    productName: { type: String, required: true },
    price: { type: Number, required: true },
    image: { type: String, required: true}
});

// Create a Mongoose Model
const User = mongoose.model('data1', userSchema);

// API Endpoint: Get all users
app.get('/api/users', async (req, res) => {
    try {
        const users = await User.find();
        res.status(200).json(users);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching users' });
    }
});

// API Endpoint: Add a new user
app.post('/api/users', async (req, res) => {
    try {
        const newUser = new User(req.body);
        const savedUser = await newUser.save();
        res.status(201).json(savedUser);
    } catch (error) {
        res.status(400).json({ error: 'Error adding user' });
    }
});

// API Endpoint: Delete a user by ID
app.delete('/api/users/:id', async (req, res) => {
    try {
        const deletedUser = await User.findByIdAndDelete(req.params.id);
        if (!deletedUser) {
            return res.status(404).json({ error: 'User not found' });
        }
        res.status(200).json(deletedUser);
    } catch (error) {
        res.status(500).json({ error: 'Error deleting user' });
    }
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
});