<script>
const element = document.getElementById("id01");
element.innerHTML = "this is para two";
</script>