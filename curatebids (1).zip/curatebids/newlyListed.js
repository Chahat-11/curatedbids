document.addEventListener("DOMContentLoaded", () => {
    fetch("newlyListedData.json")
        .then(response => response.json())
        .then(data => {
            populateNewlyListed(data.newlyListed);
        })
        .catch(error => console.error("Error fetching newly listed data:", error));
});

function populateNewlyListed(newlyListedItems) {
    const container = document.querySelector(".newly-listed-container");
    container.innerHTML = ""; // Clear any existing content

    newlyListedItems.forEach(item => {
        const newItem = document.createElement("div");
        newItem.className = "new-item";

        const itemPhoto = document.createElement("div");
        itemPhoto.className = "item-photo";
        const img = document.createElement("img");
        img.src = item.image;
        img.alt = item.productName;
        itemPhoto.appendChild(img);

        const itemInfo = document.createElement("div");
        itemInfo.className = "item-info";
        const productName = document.createElement("p");
        productName.textContent = `Product Name: ${item.productName}`;
        const startingBid = document.createElement("p");
        startingBid.textContent = `Starting Bid: $${item.startingBid}`;
        
        const bidButton = document.createElement("button");
        bidButton.className = "bid-now";
        bidButton.textContent = "Bid Now";

        itemInfo.appendChild(productName);
        itemInfo.appendChild(startingBid);
        itemInfo.appendChild(bidButton);

        newItem.appendChild(itemPhoto);
        newItem.appendChild(itemInfo);
        container.appendChild(newItem);
    });
}