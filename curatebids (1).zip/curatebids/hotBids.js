document.addEventListener("DOMContentLoaded", () => {
    fetch("hotBidsData.json")
        .then(response => response.json())
        .then(data => {
            populateHotBids(data.hotBids);
        })
        .catch(error => console.error("Error fetching hot bids data:", error));
});

function populateHotBids(hotBids) {
    const bidsContainer = document.querySelector(".bids-container");
    bidsContainer.innerHTML = ""; // Clear any existing content

    hotBids.forEach(item => {
        const bidItem = document.createElement("div");
        bidItem.className = "bid-item";

        const bidImage = document.createElement("div");
        bidImage.className = "bid-image";
        const img = document.createElement("img");
        img.src = item.image;
        img.alt = item.productName;
        bidImage.appendChild(img);

        const bidDetails = document.createElement("div");
        bidDetails.className = "bid-details";
        const productName = document.createElement("p");
        productName.textContent = `Product Name: ${item.productName}`;
        const currentBid = document.createElement("p");
        currentBid.textContent = `Current Bid: $${item.currentBid}`;

        bidDetails.appendChild(productName);
        bidDetails.appendChild(currentBid);

        bidItem.appendChild(bidImage);
        bidItem.appendChild(bidDetails);
        bidsContainer.appendChild(bidItem);
    });
}